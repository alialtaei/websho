﻿using Microsoft.AspNetCore.Mvc;

namespace bmerketo_webshop.Controllers;

public class NotImplementedController : Controller
{
    public IActionResult Index()
    {
        return View();
    }
}
